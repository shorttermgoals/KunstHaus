<header>
    <h1>OBJETOS KUNST</h1>
    <h2><?php  if(isset($_SESSION['id_usuario'])) echo "HOLA ".$_SESSION['nombre'] ?></h2>
</header>