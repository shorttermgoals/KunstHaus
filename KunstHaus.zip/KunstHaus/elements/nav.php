<nav>
    <img src="../images/logos/FullLogo2.png">
</nav>